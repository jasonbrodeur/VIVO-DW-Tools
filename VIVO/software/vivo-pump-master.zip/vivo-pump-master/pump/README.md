# The Pump

The Pump is a general purpose flat file to graph representation transformer.  It can be used to take
data in "spreadsheets" (CSV or other delimited text-based files) and produce RDF for representing the
data as a graph.  It can be used to take a graph and return a postion as tabular data.

The Pump is used with VIVO definitions to manage data in VIVO using spreadsheets.

Simple VIVO is a command line interface program that uses the Pump to perform data management tasks for VIVO.
Using Simple VIVO, a data manger can get data from VIVO, edit it using spreadsheets and update VIVO using the
edited spreadsheet.