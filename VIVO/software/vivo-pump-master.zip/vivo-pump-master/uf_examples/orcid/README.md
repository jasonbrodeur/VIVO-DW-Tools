# Add ORCID to VIVO

This example can be used to add ORCID identifiers to VIVO.  The data is very simple, a column of ORCID
in the form http://orcid.org/nnnn-nnnn-nnnn-nnnn and a column of URI for the people having each ORCID.

The def file can be used to list people and their ORCID (get) or manage ORCID for people in VIVO (update).

