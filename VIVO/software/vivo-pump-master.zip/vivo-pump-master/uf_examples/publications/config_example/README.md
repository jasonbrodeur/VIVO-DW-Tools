# config_example folder

The goal of this folder is to store example of config files that can be copied
to a `config` folder and modified without the risk of commiting it to the
repository.

Notes:

* The Makefile tasks refer to `config` folder not `config_example`
* The `config` folder has an entry in the main .gitignore file 
