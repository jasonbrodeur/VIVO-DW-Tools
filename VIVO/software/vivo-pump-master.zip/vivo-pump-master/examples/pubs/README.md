# Managing Publications using Simple VIVO

With Simple VIVO, you can enter information about publications -- journal articles, books, and many
other kinds of scholarly works -- using a single spreadsheet.

