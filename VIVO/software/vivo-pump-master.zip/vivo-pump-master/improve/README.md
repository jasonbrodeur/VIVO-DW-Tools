# Improve Functions

Simple functions for improving text data values.  Each function takes a string and returns and improved
value of the string.