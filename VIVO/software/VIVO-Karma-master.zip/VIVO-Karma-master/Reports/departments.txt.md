# departments.txt

## Add Column

## Add Node/Literal

## PyTransforms
#### _org_ID_URI_
From column: _org_ID_
``` python
return "http://vivo.northwestern.edu/n"+getValue("org_ID")
```


## Selections

## Semantic Types
| Column | Property | Class |
|  ----- | -------- | ----- |
| _org_ID_ | `vlocal:orgID` | `vivo:AcademicDepartment1`|
| _org_ID_URI_ | `uri` | `vivo:AcademicDepartment1`|
| _org_name_ | `rdfs:label` | `vivo:AcademicDepartment1`|


## Links
| From | Property | To |
|  --- | -------- | ---|
